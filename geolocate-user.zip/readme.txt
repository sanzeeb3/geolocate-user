=== Geolocate User - Store and display geolocation data of WordPress users ===
Contributors: sanzeeb3
Tags: geolocation, google maps, user location, user ip,
Requires at least: 4.0
Tested up to: 6.0
Requires PHP: 5.6
Stable tag: 1.0.0

Stores and displays geolocation data of WordPress users.

== Description ==

Stores IP address and displays geolocation data along with google maps of WordPress users during registration. Supports all all registration forms including native WordPress registration form and WooCommrece registration form. Uses Services:
* ipinfo.io-
* ip-api.com
* ipapi.co-
* ipify
* ipecho
* whatismyipaddress


== Changelog == 

- 1.0.0 - xx/xx/2019 -

* Initial Release.
